export interface SearchResponse {
  success : true;
  result : { 
    list:Array<object>,
    count :0,
    pageNo :0
  };
}


export interface RecordResponse {
  success : true;
  result 
}